using System;

namespace iTextSharp.text.rtf {
	public interface IEventListener	{
	}
}